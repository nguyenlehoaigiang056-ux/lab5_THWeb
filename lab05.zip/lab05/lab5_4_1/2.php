<?php
if (isset($_GET["id"])) {
    $id = $_GET["id"];
    echo "ID nhận được là: " . $id;
}
?>
