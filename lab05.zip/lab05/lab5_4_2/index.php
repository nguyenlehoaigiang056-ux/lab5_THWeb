
<?php
$ten = "";
$cachTim = "";
$loai = "";

if (isset($_GET["timkiem"])) {
    $ten = $_GET["ten"];
    $cachTim = $_GET["cachtim"];
    $loai = $_GET["loai"];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tìm kiếm sản phẩm</title>
</head>
<body>

<h2>TÌM KIẾM SẢN PHẨM</h2>

<form method="get" action="">
    Tên sản phẩm:
    <input type="text" name="ten"
           value="<?php echo htmlspecialchars($ten); ?>">
    <br><br>

    Cách tìm:
    <input type="radio" name="cachtim"
           value="Gần đúng" checked> Gần đúng

    <input type="radio" name="cachtim"
           value="Chính xác"> Chính xác
    <br><br>

    Loại sản phẩm:
    <select name="loai">
        <option value="tatca">Tất cả</option>
        <option value="loai1">Loại 1</option>
        <option value="loai2">Loại 2</option>
        <option value="loai3">Loại 3</option>
    </select>
    <br><br>

    <input type="submit" name="timkiem"
           value="Tìm kiếm">
</form>

<hr>

<?php
if (isset($_GET["timkiem"])) {
    echo "<h3>THÔNG TIN TÌM KIẾM</h3>";

    echo "Tên sản phẩm: " . htmlspecialchars($ten) . "<br>";

    echo "Cách tìm: " . htmlspecialchars($cachTim) . "<br>";

    if ($loai != "tatca") {
        echo "Loại sản phẩm: " . htmlspecialchars($loai);
    }
}
?>

</body>
</html>
